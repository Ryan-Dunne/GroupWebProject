/*student name: abigail murray
student number: C00260073
javascript file used for adding a new car */

// Function for confirm insert, if the user confirms they want to add details to the database

function confirmInsert() {
    var registration = document.getElementById('registration').value;
    var chassis = document.getElementById('chassis').value;
    var doors = document.getElementById('doors').value;
    var price = document.getElementById('price').value;
    var colour = document.getElementById('colour').value;
    var bodyStyle = document.getElementById('bodyStyle').value;
    var carType = document.getElementById('carType').value;
    var dateAdded = document.getElementById('dateAdded').value;
  
    // Confirm the submission
    return confirm('Are you sure you want to insert the record?');
	
    }


// Function to set the current date in the "Date Added" input field -- default to system date 
function setCurrentDate() {
    var currentDate = new Date().toISOString().split('T')[0];  // Get the current date in the format "YYYY-MM-DD"
    document.getElementById('dateAdded').value = currentDate;  // Set the value of the "Date Added" input field
}

// Call the function to set the current date when the form loads
window.onload = setCurrentDate;

