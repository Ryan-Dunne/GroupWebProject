<?php
/*TO DO- DONT FORGET ABOUT CAR TYPE*/
/*document.getElementById("amendcarId").value = carDetails[0];
            document.getElementById("amendregistration").value = carDetails[1];
            document.getElementById("amendcolour").value = carDetails[2];
            document.getElementById("amendchassisNumber").value = carDetails[3];
            document.getElementById("amendbodyStyle").value = carDetails[4];
			document.getElementById("amenddoors").value = carDetails[5];
			document.getElementById("amendprice").value = carDetails[6];
			document.getElementById("amenddateAdded").value = carDetails[7];
			document.getElementById("amendcurrentStatus").value = carDetails[8];
			document.getElementById("amendCarType").value = carDetails[9];*/
/*student name: Abigail Murray
student number:C00260073
file used for generating a listbox of cars with fields from database*/ 


include "db.inc.php" ; //database connection
date_default_timezone_set('UTC');

$sql = "SELECT carID, registration, colour, chassisNumber, bodyStyle, doors, price, dateAdded, currentStatus FROM car where deleted_flag=0"; //deleted_flag=0 to get all NOT  deleted
if (!$result = mysqli_query($con, $sql))
{
    die ('Error in querying the database' . mysqli_error($con));/*use die instead of echo so it stops */

}


echo "<br> <select name ='listbox' id='listbox' onclick='populate()'> ";//generates listbox

while($row = mysqli_fetch_array($result))//to fetch all rows in result set
{
    $id = $row['carID'];
    $reg = $row['registration'];
    $colour = $row['colour'];
	$chassis = $row['chassisNumber'];
	$style = $row['bodyStyle'];
	$doors = $row['doors'];
   	$price = $row['price'];
    $dateAdded=$row['dateAdded'];
    $dAdded = date_create($row['dateAdded']);
    $dAdded= date_format($dAdded,"Y-m-d");
    $allText = "$id,$reg,$colour,$chassis,$style,$doors,$price,$dAdded";
    echo "<option value= '$allText' > $id $reg</option>";
}
echo "</select>";
mysqli_close($con);//closing connection to database

?>
