<!--list box for car type-->
<?php 
 include "db.inc.php";/*allows us to connect + checks connection */
 date_default_timezone_set('UTC');


 // Retrieve car data from the database
 $sql = "SELECT modelName, version, engineSize, fuelType, manufacturer FROM carType"; 
 $result = $con->query($sql);

// Generate options for the select dropdown
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    // Modify the option value and display text based on the selected fields
    echo "<option value=\"" . $row["modelName"] . "\">" . $row["modelName"] . " - " . $row["version"] . " - " . $row["engineSize"] . " - " . $row["fuelType"] . " - " . $row["manufacturer"] . "</option>";
  }
} else {
  echo "<option value=\"\">No car types available</option>";
}


// Close the database connection
$con->close();
?>